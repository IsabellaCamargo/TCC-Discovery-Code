<?php
    session_start();
    include_once "conexao.php";

    //Pega o id por GET que está armazenado no link do index
    $id = filter_input(INPUT_GET, 'IDusuario', FILTER_SANITIZE_STRING);

    //se a var id não estiver vazia 
    if(!empty($id)){
        //deleta usuário
        $result_usuario = "DELETE FROM usuario WHERE IDusuario='$id'";
        $resultado_usuario = mysqli_query($conexao, $result_usuario);
        if(mysqli_affected_rows($conexao)){
            //se der tudo certo aparece isso
            $_SESSION['msg'] = "<p style='color:green;'>Usuário apagado com sucesso</p>";
            header("Location: index.php");
        }else{
            //se não
            $_SESSION['msg'] = "<p style='color:red;'>Erro o usuário não foi apagado com sucesso</p>";
            header("Location: index.php");
        }
    }else{	
        $_SESSION['msg'] = "<p style='color:red;'>Necessário selecionar um usuário</p>";
        header("Location: index.php");
    }
?>
