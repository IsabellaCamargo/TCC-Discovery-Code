<?php
    include_once 'conexao.php';

    $email = filter_input(INPUT_POST, 'emailLog');
    $sql = "SELECT * FROM `usuario` WHERE `email` = '{$email}'"; //monto a query

    $query = $conexao->query( $sql ); //executo a query

    if( $query->num_rows > 0 ) { //se retornar algum resultado
        echo 'Já existe!';
    } else {
        echo 'Não existe ainda!';
    }
?>