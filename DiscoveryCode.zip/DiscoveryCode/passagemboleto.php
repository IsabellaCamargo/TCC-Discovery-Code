<?php 
    include_once 'conexao.php';

    //id do usuario
    $id         = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_STRING);

    //nome do material
    $tipo       = filter_input(INPUT_POST, 'nomeMat', FILTER_SANITIZE_STRING);

    //status do pagamento 0 == não pago
    $stt        = 0;

    //valor do material
    $valor      = filter_input(INPUT_POST, 'valorMat', FILTER_SANITIZE_STRING);

    //As duas formas de pagamento
    $forma      = filter_input(INPUT_POST, 'forma', FILTER_SANITIZE_STRING);

    $query_usuario  = "INSERT INTO cursos (tipo, valor, IDusuario, statusPag) VALUES ('$tipo','$valor','$id','$stt')";
    mysqli_query($conexao, $query_usuario); 

    if(mysqli_insert_id($conexao)){
        echo true;
    }else{
        echo false;
    }

?>